﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;

namespace DemoNamespace
{
    /// <summary>Base class for all objects in the db4o database, containing the basic construct used by all objects.</summary>
    [Serializable]
    public abstract class Database_Object
    {
        // Class fields:
        /// <summary>Write protection to maintain data integrity of this object.</summary>
        private uint ui_writeProtect;

        /// <summary>The unique identifier of this object.</summary>
        protected string s_ID;

        /* * * * * * * * * * * * * * * * * * * * * * * * * */

        // Constructors:
        /// <summary>Default Constructor. Initializes the write protect of this object to default.</summary>
        /// <param name="s_ID">The ID of this object.</param>
        public Database_Object(string s_ID)
        {
            ui_writeProtect = 0;

            s_ID = string.Copy(s_ID);
        } // end Default Constructor

        /// <summary>Copy Constructor for this class.</summary>
        /// <param name="other">Object to copy.</param>
        public Database_Object(Database_Object other)
        {
            ui_writeProtect = other.ui_writeProtect;
            s_ID = string.Copy(other.s_ID);
        } // end Copy Constructor

        /* * * * * * * * * * * * * * * * * * * * * * * * * */

        // General Getters/Setters:
        /// <summary>Getter for the write protect value of this object.</summary>
        public uint WP => ui_writeProtect;

        public string ID
        {
            get
            {
                return s_ID;
            }
            set
            {
                s_ID = value;
            }
        }

    /* * * * * * * * * * * * * * * * * * * * * * * * * */

            // Methods:
            /// <summary>Updates the value of write protect of this object.</summary>
            /// <remarks>If the uint.Max value is reached, the overflow will be ignored, and the write protect is reset to 0.</remarks>
        public void ObjectAltered()
        {
            // overflow will simply reset the counter to 0
            unchecked
            {
                ui_writeProtect++;
            } // end unchecked
        } // end method objectAltered

        /// <summary>Default hashing function.</summary>
        /// <returns>Hash code for this object.</returns>
        public override int GetHashCode()
        {
            var hashCode = 987006414;
            hashCode = hashCode * -1521134295 + ui_writeProtect.GetHashCode();
            hashCode = hashCode * -1521134295 + EqualityComparer<string>.Default.GetHashCode(s_ID);
            hashCode = hashCode * -1521134295 + WP.GetHashCode();
            hashCode = hashCode * -1521134295 + EqualityComparer<string>.Default.GetHashCode(s_ID);
            return hashCode;
        } // end method GetHashCode

        /// <summary>Equals operator for comparing two Database Objects.</summary>
        /// <param name="obj">Operand being compared to this object.</param>
        /// <returns>True if the two objects are equal, otherwise false.</returns>
        public override bool Equals(object obj)
        {
            Database_Object d = (Database_Object)obj;
            return string.Equals(s_ID, d.s_ID);
        } // end method Equals
    } // end Class Database_Object
    /// <summary>Class storing the name, ID, and prerequisits for a course.</summary>
    [Serializable()]
    public class Course : Database_Object, IComparable
    {
        // Class fields:
        /// <summary>Number of quarters per year constant.</summary>
        private const uint ui_NUMBERQUARTERS = 4;

        /// <summary>The number of credits this course is worth.</summary>
        private uint ui_numberCredits;

        /// <summary>Name of this course.</summary>
        private string s_name;

        /// <summary>Prerequisites for this course.</summary>
        private List<Course> l_preRequisites;

        /// <summary>The quarters this course is offered, [0] = Winter, [3] = Fall.</summary>
        private bool[] ba_quartersOffered;

        /// <summary>Stores whether or not this quarter requires a student to be in the CS major to take it.</summary>
        private bool b_requiresMajor;

        /* * * * * * * * * * * * * * * * * * * * * * * * * */

        // Constructors:
        /// <summary>Default Constructor.</summary>
        public Course() : base("")
        {
            s_name = "";
            ui_numberCredits = 0;
            b_requiresMajor = false;

            ba_quartersOffered = new bool[ui_NUMBERQUARTERS];

            l_preRequisites = new List<Course>();
        } // end default Constructor

        /// <summary>Constructor which creates a Course object with a name and ID, and sets all other fields to default.</summary>
        /// <param name="s_name">The course name.</param>
        /// <param name="s_ID">The course identifier.</param>
        /// <param name="ui_numberCredits">The number of credits this course is worth.</param>
        /// <param name="b_requiresMajor">The status of this course requiring a student to be in the CS major.</param>
        /// <remarks>The course name is the actual name of the course, e.g. Computer Architecture 1.
        ///          The course identifier is the unique identifier for this course, e.g. CS311 which must not contain spaces.</remarks>
        public Course(string s_name, string s_ID, uint ui_numberCredits, bool b_requiresMajor) : base(s_ID)
        {
            this.s_name = string.Copy(s_name);
            this.ui_numberCredits = ui_numberCredits;
            this.b_requiresMajor = b_requiresMajor;
            ID = s_ID;

            ba_quartersOffered = new bool[ui_NUMBERQUARTERS];

            l_preRequisites = new List<Course>();
        } // end Constructor

        /// <summary>Copy Constructor which creates a copy of the other course.</summary>
        /// <param name="c_other">Course to be copied.</param>
        public Course(Course c_other) : base(c_other)
        {
            s_name = string.Copy(c_other.s_name);
            ui_numberCredits = c_other.ui_numberCredits;
            b_requiresMajor = c_other.b_requiresMajor;

            ba_quartersOffered = new bool[ui_NUMBERQUARTERS];

            Array.Copy(c_other.ba_quartersOffered, ba_quartersOffered, ui_NUMBERQUARTERS);

            l_preRequisites = new List<Course>(c_other.l_preRequisites);
        } // end Copy Constructor

        /* * * * * * * * * * * * * * * * * * * * * * * * * */


        /// <summary>Getter for PreRequisites list of this course.</summary>
        /// <remarks>The returned collection will be a read-only collection, and may not be modified directly.</remarks>
        public ReadOnlyCollection<Course> PreRequisites => (l_preRequisites.AsReadOnly());

        /// <summary>Getter for quarters offered array of this course.</summary>
        public bool[] QuartersOffered => ba_quartersOffered;
        

        /* * * * * * * * * * * * * * * * * * * * * * * * * */

            // IComparable Implementation:
            /// <summary>Comparer for Course class. Required for using List class.</summary>
            /// <param name="obj">Object being compared to this object.</param>
            /// <returns>-1 if this is less than other; 0 if this is = other; 1 if this is greater than other.</returns>
        int IComparable.CompareTo(object obj)
        {
            Course c = (Course)obj;
            return string.Compare(base.s_ID, c.s_ID);
        } // end method CompareTo

        /* * * * * * * * * * * * * * * * * * * * * * * * * */

        // QuartersOffered getters/setters:
        /// <summary>Checks whether this course is offered in the specified quarter.</summary>
        /// <param name="se_i">Quarter to check.</param>
        /// <remarks>Quarter 0 is Winter, quarter 3 is fall.</remarks>
        /// <returns>True if offered, false if not offered.</returns>
        public bool IsOffered(int se_i) => ba_quartersOffered[(int)se_i];

        /// <summary>Sets a specific quarter to the given status.</summary>
        /// <param name="se_i">Quarter to set.</param>
        /// <param name="b_status">The new offering-status for this course in the specified quarter.</param>
        /// <remarks>Quarter 0 is Winter, quarter 3 is fall.
        ///          True = offered, False = not offered
        ///          This will change only a single quarter, to change all use <see cref="SetQuarterOffered(bool[])"/>.
        /// </remarks>
        public void SetQuarterOffered(int se_i, bool b_status) => ba_quartersOffered[(int)se_i] = b_status;

        /// <summary>Setter for quarters offered array of this course.</summary>
        /// <param name="ba_quarters">Array containing the new offering-status of this course for all quarters.</param>
        /// <remarks>Quarter 0 is Winter, quarter 3 is fall.
        ///          True = offered, False = not offered
        ///          All previous offerings will be overriden by this method. To change only a single quarter use <see cref="SetQuarterOffered(Season, bool)"/>.
        /// </remarks>
        /// <exception cref="System.ArgumentException">This exception is thrown if the ba_quarters array is not size 4.</exception>
        public void SetQuarterOffered(bool[] ba_quarters)
        {
            if (ba_quarters.Length != ui_NUMBERQUARTERS)
            {
                throw new ArgumentException("Invalid Array size of ba_quarters passed to setQuarterOffered. Expected: 4; Actual: " + ba_quarters.Length);
            } // end if

            for (int i = 0; i < ui_NUMBERQUARTERS; i++)
            {
                ba_quartersOffered[i] = ba_quarters[i];
            } // end for
        } // end method setQuarterOffered

        /* * * * * * * * * * * * * * * * * * * * * * * * * */

        // Prerequisite setters:
        /// <summary>Adds the given Course to the prerequisites list of this Course object.</summary>
        /// <param name="c_course">A course prerequisites for this course to be added to the prerequisites list.</param>
        public void AddPreRequisite(Course c_course)
        {
            if (!l_preRequisites.Contains(c_course))
            {
                l_preRequisites.Add(c_course);
            } // end if
        } // end method addPreRequisite

        /// <summary>Adds the given Courses to the prerequisites list of this Course object.</summary>
        /// <param name="col_courses">A collection of prerequisites for this course to be added to the prerequisites list.</param>
        public void AddPreRequisite(ICollection<Course> col_courses)
        {
            foreach (Course c_course in col_courses)
            {
                if (!l_preRequisites.Contains(c_course))
                {
                    l_preRequisites.Add(c_course);
                } // end if
            } // end foreach
        } // end method addPreRequisite

        /// <summary>Removes the course whith the specified ID from the prerequisites of this Course object, given it exists.</summary>
        /// <param name="s_courseID">The ID of the course to be removed from to the prerequisites list.</param>
        /// <returns>True if the course was found, and successfully removed. False if it could not be removed.</returns>
        public bool RemovePreRequisite(string s_courseID)
        {
            foreach (Course course in l_preRequisites)
            {
                if (course.s_ID == s_courseID)
                {
                    return l_preRequisites.Remove(course);
                } // end if
            } // end foreach

            return false; // not found
        } // end method removePreRequisite

        /// <summary>Removes all prerequisites of this Course object.</summary>
        public void ClearPreRequisites() => l_preRequisites.Clear();

        /// <summary>Turns the data in this object into a string.</summary>
        /// <returns>A string representation of this object.</returns>
        public override string ToString()
        {
            string str = "Course name: " + s_name + "\nCourse ID: " + ID + "\nCredits: " + ui_numberCredits + "\nQuarters offered: ";

            if (ba_quartersOffered[0])
            {
                str += "Winter ";
            }
            if (ba_quartersOffered[1])
            {
                str += "Spring ";
            }
            if (ba_quartersOffered[2])
            {
                str += "Summer ";
            }
            if (ba_quartersOffered[3])
            {
                str += "Fall";
            }

            str += "\nRequires Major: " + b_requiresMajor.ToString();

            str += "\nPrerequisites: ";

            if (l_preRequisites.Count == 0)
            {
                str += "None";
            }
            else
            {
                foreach (Course c in l_preRequisites)
                {
                    str += c.ID + " ";
                }
            }

            return str;
        }
    } // end Class Course 
} // end Namespace Database_Object_Classes