﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;
using iTextSharp.text.pdf;
using iTextSharp.text.pdf.parser;
using System.IO;

namespace readTranscriptTest
{
    public partial class UI : Form
    {
        public UI()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string text = ReadPdfFile(textBox1.Text);
            richTextBox1.Text = text;
            ProcessTranscriptText(text);
        }

        public string ReadPdfFile(string fileName)
        {
            StringBuilder text = new StringBuilder();

            if (File.Exists(fileName))
            {
                PdfReader pdfReader = new PdfReader(fileName);

                for (int page = 1; page <= pdfReader.NumberOfPages; page++)
                {
                    ITextExtractionStrategy strategy = new SimpleTextExtractionStrategy();
                    string currentText = PdfTextExtractor.GetTextFromPage(pdfReader, page, strategy);

                    currentText = Encoding.UTF8.GetString(ASCIIEncoding.Convert(Encoding.Default, Encoding.UTF8, Encoding.Default.GetBytes(currentText)));
                    text.Append(currentText);
                }
                pdfReader.Close();
            }
            return text.ToString();
        }


        private void ProcessTranscriptText(string text)
        {
            StringBuilder extractedText = new StringBuilder();

            List<DemoNamespace.Course> completed = new List<DemoNamespace.Course>();

            string[] textArr = text.Split(new char[] {' ', '\n' });
            List<string[]> processed = new List<string[]>();
            string output = string.Empty;

            HashSet<string> courses = new HashSet<string>();
            courses.Add("CS");
            courses.Add("ART");
            courses.Add("HED");
            courses.Add("MATH");
            courses.Add("HIST");

            HashSet<string> quarters = new HashSet<string>();
            quarters.Add("Winter");
            quarters.Add("Spring");
            quarters.Add("Fall");
            quarters.Add("Summer");


            for (int i = 0; i < textArr.Length; i++)
            {
                if(quarters.Contains(textArr[i]))
                {
                    string[] temp = new string[2];
                    temp[0] = textArr[i];
                    temp[1] = textArr[i + 1];
                    processed.Add(temp);
                    i++;
                }
                else if(courses.Contains(textArr[i]))
                {
                    int result;

                    if (Int32.TryParse(textArr[i+1], out result))
                    {
                        if (result >= 100 && result <= 600)
                        {
                            string[] temp = new string[4];
                            temp[0] = textArr[i] + " " + textArr[i + 1];
                            double b;
                            int  j = i + 2;

                            temp[1] = string.Empty;

                            while (!double.TryParse(textArr[j], out b))
                            {
                                temp[1] += textArr[j] + " ";
                                j++;
                            }

                            temp[2] = b.ToString();
                            
                            if(textArr[i] == "CS" && result > 200)
                            {
                                temp[3] = "T";
                            }
                            else
                            {
                                temp[3] = "F";
                            }                            
                                //textArr[i] + " " + textArr[i + 1];
                            processed.Add(temp);
                        }
                    }
                    i++;
                }
            }

            foreach(string[] words in processed)
            {
                if(words.Length == 2)
                {
                    output += " - - - - - - - - - - - - - - - - - - - - - - - - - - - ";
                    output += "\n" + "Quarter: " + words[0] + " " + words[1] + "\n";
                    output += " - - - - - - - - - - - - - - - - - - - - - - - - - - - \n\n";
                }
                else
                {
                    uint ui;
                    uint.TryParse(words[2], out ui);
                    bool major = (words[3] == "T");
                    DemoNamespace.Course temp = new DemoNamespace.Course(words[1], words[0], ui, major);

                    output += temp.ToString() + "\n\n";
                }
            }

            /*foreach(string word in processed)
            {
                output += word + "\n";
            }
            */
            richTextBox2.Text = output;
            
        }
    }
}
